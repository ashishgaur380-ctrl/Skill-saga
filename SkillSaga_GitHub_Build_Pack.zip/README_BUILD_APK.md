# Skill Saga — enhanced core build

This project upgrades the original MVP into a functional offline-first core prototype.

Included in this build:
- Skill Saga branded login/sign-up flow
- Local user accounts and session persistence
- Home dashboard, Play, Compete, Skills and Profile
- Daily quiz and quiz engine
- XP, levels, streak display, accuracy and progress
- Achievements and XP-based badge rewards
- Leaderboard
- Local Admin Console for creating/publishing quiz content
- Final Skill Saga logo asset
- Android target SDK 36 configuration

## Important production boundary
The current project is intentionally offline-first. Login, content, scores and rewards are stored locally for the prototype. A production Play Store release should replace these local mechanisms with a secure backend, server-side scoring, authentication, database, anti-cheat controls, privacy/account-deletion flows, notification service, and a proper admin service. Payment or cash-reward features should only be added after policy/legal review.

## Build
Open this folder in Android Studio with JDK 17 and Android SDK 36 installed, sync Gradle, then Build > Build Bundle(s) / APK(s).
