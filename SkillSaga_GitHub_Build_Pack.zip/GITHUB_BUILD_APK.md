# Build Skill Saga APK with GitHub Actions

1. Upload this whole project to a GitHub repository.
2. Open **Actions**.
3. Select **Build Skill Saga APK**.
4. Tap **Run workflow** (or push to `main` to trigger it).
5. Open the completed run and download the **SkillSaga-debug-apk** artifact.
6. Extract the artifact ZIP and install `app-debug.apk` on Android.

The workflow uses JDK 17, Android SDK 36 and Gradle 8.9.
