# Skill Saga — production candidate

Brand: Skill Saga
Tagline: A smarter way to learn
Android package: com.skillsaga.learn
Firebase project: skill-saga-cb695

## Included
- Final logo and branding
- Firebase Email/Password authentication
- Password reset
- Cloud learner profiles
- Daily/practice quiz loading from Firestore
- XP, levels, streaks, accuracy and badges
- Leaderboard
- Rewards based on XP (non-cash achievement rewards)
- Profile and account deletion flow
- Admin console for authorized accounts
- Quiz publishing/scheduling fields
- Local cache/fallback for development
- Android target SDK 36

## Firebase
Authentication: Email/Password enabled.
Firestore: database created.

Before release, publish `firestore.rules` in Firebase Console. Create the first admin user by creating/updating its `users/{UID}` document in Firestore with role `admin` only after the account exists. Never expose admin credentials in the app.

## Important release limitation
The app uses client-side XP calculation because the project is kept on Firebase's no-cost setup. For cash-value rewards, payments, or high-stakes competition, move scoring/reward issuance to trusted server code (for example Cloud Functions) before launch. This project intentionally keeps rewards as in-app achievement badges.

## Build
Open this folder in Android Studio and sync Gradle. Build a signed Android App Bundle (.aab) for Play Console. Test login, signup, reset password, quiz completion, streaks, leaderboard, admin publishing and account deletion on physical devices before production release.
