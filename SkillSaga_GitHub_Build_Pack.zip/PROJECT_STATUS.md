Skill Saga production candidate updated September 2026.
Firebase project: skill-saga-cb695
Android package: com.skillsaga.learn
Core user journey and Firebase cloud persistence implemented.
Next external release actions: publish Firestore rules, designate admin account, build/sign AAB, complete Play Console listing/testing/policy declarations, and test on real devices.
