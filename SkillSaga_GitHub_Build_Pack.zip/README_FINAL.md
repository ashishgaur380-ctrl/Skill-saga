# Skill Saga — production integration build

Brand: **Skill Saga**
Tagline: **A smarter way to learn**
Android package: `com.skillsaga.learn`
Firebase project: `skill-saga-cb695`

This build upgrades the previous offline MVP with Firebase Authentication and Firestore integration while retaining an offline cache/fallback for development.

## Included
- Final Skill Saga logo
- Login / Sign up using Firebase Email/Password
- User profile and cloud-synced learner data
- Home / Play / Compete / Skills / Profile
- Daily quiz engine
- XP, levels, streaks, accuracy and badges
- Leaderboard
- Rewards foundation
- Quiz content loaded from Firestore when published
- Local admin/content foundation retained for development
- Android target SDK 36

## Important before public release
- Enable Email/Password in Firebase Authentication.
- Create Firestore and replace development/test rules with secure production rules.
- Add a real admin authorization mechanism (custom claims or a locked-down admin backend) before allowing quiz publishing in production.
- Add production privacy policy, account deletion flow, Data Safety declaration, notification handling, crash monitoring and final Play Store assets.
- Build and test a signed Android App Bundle (`.aab`) from Android Studio.

The Firebase web SDK is loaded over HTTPS by the WebView. Internet permission is enabled in AndroidManifest.xml.
