# Skill Saga Firebase setup

The Android package is `com.skillsaga.learn` and the Firebase project is `skill-saga-cb695`.

Before first production test:

1. Firebase Console → Authentication → Sign-in method → enable **Email/Password**.
2. Firebase Console → Firestore Database → Create database. For initial setup, choose a suitable region and start in test mode only while configuring. Before launch, replace test rules with secure production rules.
3. Add the following Firestore collections used by the app:
   - `users` — one document per Firebase Auth UID
   - `quizzes` — published quiz documents
4. A quiz document should contain: `title`, `category`, `difficulty`, `xp`, `date`, `type`, `published`, `questions`.
5. Before Play Store launch, configure secure Firestore rules so users can read published quizzes and their own user document, while only authorized admins can publish content or change protected reward/score fields.

The app contains the Firebase configuration from the registered Android app and also keeps a local fallback cache for resilience during development.
